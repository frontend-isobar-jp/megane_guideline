import Common from './component/common';

////

const Init = () => {

	Common();

}

Init();
